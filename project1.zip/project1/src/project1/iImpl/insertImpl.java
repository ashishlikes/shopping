package project1.iImpl;

public class insertImpl {

}
