package project1.interfaces;

public interface iService {
public boolean login (String name, String password);
public void register(String firstname, String lastname, String email, String password);


}
