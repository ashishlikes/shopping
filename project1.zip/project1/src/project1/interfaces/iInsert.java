package project1.interfaces;

public interface iInsert {
	
	
	public void update(String brand, String name, String size, String description,  String price);

}
