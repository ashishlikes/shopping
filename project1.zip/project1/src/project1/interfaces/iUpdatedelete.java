package project1.interfaces;

public interface iUpdatedelete {
	
	public boolean delete (String email);
	public void update(String firstname, String lastname, String password);

}
